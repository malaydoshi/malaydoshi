﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace EmployeeManagement.Models
{
    public class SeedUserAndRoles
    {
        public static void SeedData(UserManager<ApplicationUser> userManager,RoleManager<IdentityRole> roleManager)
        {
            SeedRoles(roleManager);
            SeedUsers(userManager);
        }
        public static void SeedUsers(UserManager<ApplicationUser> userManager)
        {
            if (userManager.FindByEmailAsync("demoAdmin@atidan.com").Result == null)
            {
                ApplicationUser user = new ApplicationUser();
                user.UserName = "demoAdmin@atidan.com";
                user.Email = "demoAdmin@atidan.com";
                user.EmailConfirmed = true;
                IdentityResult result = userManager.CreateAsync(user, "DemoAdmin@12345").Result;
                if (result.Succeeded)
                {
                    userManager.AddToRoleAsync(user, "Admin").Wait();
                    userManager.AddClaimAsync(user, new Claim("Edit Role", "true")).Wait();
                    userManager.AddClaimAsync(user, new Claim("Create Role", "true")).Wait();
                    userManager.AddClaimAsync(user, new Claim("Delete Role", "true")).Wait();
                }
            }
            if (userManager.FindByEmailAsync("demoContributor@atidan.com").Result == null)
            {
                ApplicationUser user = new ApplicationUser();
                user.UserName = "demoContributor@atidan.com";
                user.Email = "demoContributor@atidan.com";
                user.EmailConfirmed = true;
                IdentityResult result = userManager.CreateAsync(user, "DemoContributor@12345").Result;
                if (result.Succeeded)
                {
                    userManager.AddToRoleAsync(user,"Contributor").Wait();
                }
            }
            if (userManager.FindByEmailAsync("demoUser@atidan.com").Result == null)
            {
                ApplicationUser user = new ApplicationUser();
                user.UserName = "demoUser@atidan.com";
                user.Email = "demoUser@atidan.com";
                user.EmailConfirmed = true;
                IdentityResult result = userManager.CreateAsync(user, "DemoUser@12345").Result;
                if (result.Succeeded)
                {
                    userManager.AddToRoleAsync(user, "User").Wait();
                }
            }
        }
        public static void SeedRoles(RoleManager<IdentityRole> roleManager)
        {
            if (!roleManager.RoleExistsAsync("Admin").Result)
            {
                IdentityRole role = new IdentityRole();
                role.Name = "Admin";
                IdentityResult roleResult = roleManager.CreateAsync(role).Result;
            }
            if (!roleManager.RoleExistsAsync("Contributor").Result)
            {
                IdentityRole role = new IdentityRole();
                role.Name = "Contributor";
                IdentityResult roleResult = roleManager.CreateAsync(role).Result;
            }
            if (!roleManager.RoleExistsAsync("User").Result)
            {
                IdentityRole role = new IdentityRole();
                role.Name = "User";
                IdentityResult roleResult = roleManager.CreateAsync(role).Result;
            }
        }
    }
}
